package com.example.railwayalarm_v10;

/**
 * Created by 魏小弟 on 2017/5/13.
 */

public class Variable {
    public static String socketAddr = "192.168.90.17";
    public static int socketPort = 9090;
//    public static Variable Variable_instance = this;
}
