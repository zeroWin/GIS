package common;

/**
 * Created by Loftor on 2014/8/15.
 */
public class BaseConfig {
    //服务器端叄1�7
    public static final int PORT = 9090;
}
